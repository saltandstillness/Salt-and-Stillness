
# Salt & Stillness Retreat Landing Page

This is a simple HTML landing page for the **Salt & Stillness** yoga & surf retreat in Nosara, Costa Rica.

## Features
- Clean, mobile-friendly design
- Daily yoga and surf retreat details
- Call-to-action with early bird discount info

## How to Use

1. Clone this repository or download the ZIP.
2. Deploy directly to [Vercel](https://vercel.com) or any static host.
3. Or open `index.html` in any browser to preview.

## Deployment

### Vercel (Recommended)
- Push this repository to your GitHub
- Import it into Vercel: https://vercel.com/import
- No build steps needed, just deploy.

### Manual Upload
- Unzip and upload `index.html` to Netlify or similar service.

---
Created with love for wanderers, yogis, and surfers.
